Replace these assets with your own visuals.

Recommended specs:
- Hero illustration: 1200x675 JPG or WEBP under 200 KB
- Icon trio: three 256x256 PNGs with transparent backgrounds
- Optional ambient loop: 30-second MP3 under 1 MB (place in this folder and reference from `index.html`)

Keep filenames lowercase and avoid spaces to simplify linking.
